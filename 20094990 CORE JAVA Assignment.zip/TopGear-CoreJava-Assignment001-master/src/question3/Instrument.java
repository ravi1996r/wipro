package question3;

abstract class Instrument {
	abstract void play();
}
