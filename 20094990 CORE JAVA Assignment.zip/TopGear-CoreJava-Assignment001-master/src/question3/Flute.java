package question3;

class Flute extends Instrument {
	void play() {
		System.out.println("toot toot toot");
	}
}
