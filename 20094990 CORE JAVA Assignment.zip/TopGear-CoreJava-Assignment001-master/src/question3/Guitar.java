package question3;

class Guitar extends Instrument {
	void play() {
		System.out.println("tin tin tin");
	}
}
