package question2;

class Horse extends Animal {
	Horse() {
		System.out.println("Horse shouts");
	}
	void shout() {
		System.out.println("neigh....neigh....neigh");
	}
}
