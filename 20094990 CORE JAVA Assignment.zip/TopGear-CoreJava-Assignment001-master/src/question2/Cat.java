package question2;

class Cat extends Animal {
	Cat() {
		System.out.println("Cat shouts");
	}
	void shout() {
		System.out.println("meow....meow....meow");
	}
}
